ASTRAVION FIREBASE V1 - SOURCE FOUNDATION

Project:
- Unity 6000.6.9f1
- Android target
- Bundle ID: com.bendot17.astravion
- Existing Firebase project: astravion-14175
- Scene: Assets/Scenes/Astravion.unity
- Build Settings: Assets/Scenes/Astravion.unity enabled

Current implementation:
- Firebase Email/Password sign-up and sign-in using Firebase Identity Toolkit REST API.
- Attempts to create/update players/{uid} in Firestore REST API.
- Basic menu, KAEL training arena, and Android-oriented starter scene.

Important limitations:
This is a source foundation/prototype, NOT a finished commercial online MOBA.
It does not yet implement authoritative real-time 5v5 networking, matchmaking,
hero roster/skins, coin/diamond economy, Google Play Billing, spectator mode,
or tournament referee workflows. Those need additional game/server implementation
and testing. Firebase Auth + Firestore alone are not a real-time multiplayer game server.

Firebase:
- Uses the existing project astravion-14175.
- Firebase Authentication Email/Password must be enabled.
- Firestore rules must allow each authenticated user to write only their own
  players/{uid} document. If profile save fails, inspect Firestore Rules.
- Firebase web API key is client configuration, not a service account secret.

Build:
- Keep Assets/Scenes/Astravion.unity enabled in Unity Build Settings.
- In Unity Build Automation, select Android and ensure the scene is included.
- Do not run repeated cloud builds until the first import/compile errors are reviewed.
